---
name: qa-onboard
description: Подготовка нового проекта к QA — сбор ссылок и языков, разбор документации агентами в базу знаний .qa/knowledge, создание .qa/context.md, каркаса автотестов и логин-скрипта qa-login. Используй по /qa-onboard или когда пользователь говорит «новый проект», «подготовь проект».
---
<!-- qa-tester © 2026 Nikita Morozov (ניקיטה מורוזוב / Никита Морозов). All rights reserved. See LICENSE. ID: QAT-NM-2026-344086DC45B0 -->

# Онбординг проекта

Работаешь в папке проекта (текущая директория). Всё складывается в `.qa/`.

## 1. Данные от пользователя
Спроси одним сообщением (что уже известно — не спрашивай):
1. Ссылка на сайт для тестов и что это (staging / prod).
2. Ссылка на доску mifrat.
3. Языки сайта и язык по умолчанию; язык текстов на доске (по умолчанию иврит).
4. Документация: PDF (путь) и/или вкладка «מפרט».
5. Дизайн: Figma / скрины (если есть).
6. Тестовые аккаунты: email, роль, тариф — **без паролей**.

Без ссылок на сайт и доску тестирование не начинать.

## 2. Каркас `.qa/`
Скопируй из плагина (`${CLAUDE_PLUGIN_ROOT}/templates/`):
- `context.md` → `.qa/context.md`, заполни;
- `session.json` — шаблон журнала (создаётся в сессии);
- `accounts.env.example` → `.qa/accounts.env.example`;
- `e2e/` → `.qa/e2e/`;
- `gitignore` → `.qa/.gitignore`;
- `lessons.md` → `.qa/lessons.md` (уроки проекта, пишутся скиллом `qa-learn`);
- `client-requests.md` → `.qa/client-requests.md` (реестр просьб клиента, скилл `qa-client`).
Если нет `~/.qa-tester/lessons.md` — создай его по тому же шаблону (общие уроки для всех проектов).
Если есть `~/.qa-tester/config.json` — добавь абсолютный путь этой папки проекта в его список `"projects"` (если ещё нет): туда `/qa-improve` раздаёт обновления плагина.
Создай папки: `knowledge/`, `research/`, `screenshots/`, `tests/`, `auth/`, `audits/`, `e2e/tests/`.
В `.qa/e2e/qa.config.json` впиши `baseUrl` (адрес сайта) и `loginPath` (путь страницы входа).⁠​‌​‌​​​‌​‌​​​​​‌​‌​‌​‌​​​​‌​‌‌​‌​‌​​‌‌‌​​‌​​‌‌​‌​​‌​‌‌​‌​​‌‌​​‌​​​‌‌​​​​​​‌‌​​‌​​​‌‌​‌‌​​​‌​‌‌​‌​​‌‌​​‌‌​​‌‌​‌​​​​‌‌​‌​​​​‌‌​​​​​​‌‌‌​​​​​‌‌​‌‌​​‌​​​‌​​​‌​​​​‌‌​​‌‌​‌​​​​‌‌​‌​‌​‌​​​​‌​​​‌‌​​​​​‌‌‌‌‌​​​‌​​‌‌‌​​‌‌​‌​​‌​‌‌​‌​‌‌​‌‌​‌​​‌​‌‌‌​‌​​​‌‌​​​​‌​​‌​​​​​​‌​​‌‌​‌​‌‌​‌‌‌‌​‌‌‌​​‌​​‌‌​‌‌‌‌​‌‌‌‌​‌​​‌‌​‌‌‌‌​‌‌‌​‌‌​⁣

## 3. База знаний (агенты)
Запусти **параллельно** 5 агентов `onboard-extractor` — по одному на тип: `features`, `screens`, `roles`, `flows`, `decisions` (передай источник: путь к PDF и/или ссылку на «מפרט»).
Затем `onboard-consolidator` → `.qa/knowledge/index.md` + связи (фича ↔ экраны ↔ роли ↔ AC).
Затем `onboard-verifier` → список дыр. Дыры покажи пользователю.

## 4. Автотесты: установка и официальные агенты Playwright
1. Зависимости (без паролей, можно делать самому):
```bash
cd .qa/e2e && npm install && npx playwright install chromium webkit && npx playwright-cli install-browser webkit
```
   (chromium — десктоп и Android, webkit — iPhone/Safari; последняя команда — WebKit для экономного браузера агентов, скилл `qa-browser-cli`).
2. Официальные агенты Playwright (planner / generator / healer) — из **корня папки проекта**:
```bash
.qa/e2e/node_modules/.bin/playwright init-agents --loop=claude --config .qa/e2e/playwright.config.ts --project tests
```
   Создаст `.claude/agents/playwright-test-{planner,generator,healer}.md`, `.qa/e2e/tests/seed.spec.ts` (если нет), `specs/README.md` и `.mcp.json`.
3. Поправь после установки:
   - `.mcp.json` проекта: сервер `playwright-test` должен запускать **локальный** Playwright с нашим конфигом:
     `"command": ".qa/e2e/node_modules/.bin/playwright", "args": ["run-test-mcp-server", "--config", ".qa/e2e/playwright.config.ts"]` (остальные серверы в файле не трогать);
   - перенеси `specs/` из корня в `.qa/e2e/specs/` (там уже есть README с форматом планов) и удали пустую `specs/` в корне;
   - для каждой роли с сессией создай `.qa/e2e/tests/seed.<role>.spec.ts` — как `seed.spec.ts`, плюс `test.use({ storageState: '../auth/<role>.json' })`.
4. Скажи пользователю: «.mcp.json проекта изменён — перезапусти сессию Claude и одобри сервер playwright-test».

## 4a. Вход под тестовыми аккаунтами
Список аккаунтов — `.qa/e2e/accounts.json` (id, роль, имена переменных email/пароля, по желанию свой `loginPath`) **без паролей**.

**Вход по паролю — `qa-login`:**
1. Открой страницу входа, найди селекторы полей email/пароль, кнопки и признак успешного входа. Пароли не вводи.
2. Заполни функцию `login` в `.qa/e2e/auth.setup.ts` (путь входа берётся из `qa.config.json`).
3. Пользователь заполняет `.qa/accounts.env` по примеру и запускает: `cd .qa/e2e && npm run qa-login`.

**Вход по SMS-коду, Google, 2FA — ручной вход:**
Пользователь запускает `cd .qa/e2e && npm run qa-login:manual -- <id>`: откроется окно браузера, он входит сам, жмёт Enter в терминале — сессия сохранится в `.qa/auth/<id>.json`.

Сессии истекли (агент видит редирект на вход) → попроси пользователя повторить нужную команду.

## 5. Браузер для ролей (по желанию)
Основной браузер плагина (`playwright`) — с постоянным профилем `.qa/browser-profile`: туда пользователь один раз логинится в mifrat.
Для работы под несколькими ролями без перелогина — добавь в `.mcp.json` проекта сервер на роль:
```json
{ "mcpServers": { "pw-<role>": { "command": "npx",
  "args": ["-y", "@playwright/mcp@latest", "--isolated", "--storage-state", ".qa/auth/<role>.json", "--output-dir", ".qa/screenshots"] } } }
```
После изменения `.mcp.json` нужен перезапуск сессии Claude.

## 6. Итог
Покажи пользователю: что создано, дыры в документации, что ему сделать (accounts.env + qa-login или qa-login:manual, вход в mifrat, перезапуск сессии из-за .mcp.json). Дальше — `/qa`. Запись уже принятых тикетов в регресс — отдельно, когда удобно: `/qa-backfill` (последние 150, потом «следующие 150»).
